
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class TollPlaza {

  enum Vehicle {
    CAR(40),
    TRUCK(80),
    BUS(80);
    int fare;

    Vehicle(int fare) {
      this.fare = fare;
    }
  }

  private Map<String, Vehicle> vehicleMap;

  public TollPlaza() {
    vehicleMap = new HashMap<>();
  }

  private void addVehicle(String vehicleNumber, Vehicle vehicle) {
    vehicleMap.put(vehicleNumber, vehicle);
    System.out.println("Vehicle has been added");
  }

  public void calculateTotalFare() {
    long totalFare = 0;
    for (Map.Entry<String, Vehicle> entry : vehicleMap.entrySet()) {
      totalFare = totalFare + entry.getValue().fare;
    }
    System.out.println("Total toll collection: " + totalFare);
  }

  public void clearVehicle(String vehicleNumber) {
    if (vehicleMap.containsKey(vehicleNumber)) {
      vehicleMap.remove(vehicleNumber);
      System.out.println("Vehicle has been cleared:" + vehicleNumber);
    }
    System.out.println("Vehicle is not added to the system.");
  }

  public void tollOperations() {
    System.out.println("1. Add new vehicle");
    System.out.println("2. Calculate total toll fare");
    System.out.println("3. Clear vehicle");
    System.out.println("4. Exit the system");
  }

  public void exitSystem() {
    System.exit(1);
  }

  public void processOperation(int operationType, Scanner sc) {
    switch (operationType) {
      case 1:
        System.out.println("Enter vehicle number");
        String vehicleNumber = sc.next();
        System.out.println("Enter vehicle type: CAR,TRUCK, BUS");
        Vehicle vehicle = Vehicle.valueOf(sc.next());
        this.addVehicle(vehicleNumber, vehicle);
        break;
      case 2:
        this.calculateTotalFare();
        break;
      case 3:
        System.out.println("Enter the vehicle number");
        vehicleNumber = sc.next();
        this.clearVehicle(vehicleNumber);
        break;
      case 4:
        this.exitSystem();
        break;
      default:
        System.out.println("Invalid choice");
        break;

    }
  }

  public static void main(String[] args) {
    TollPlaza tollPlaza = new TollPlaza();
    Scanner sc = new Scanner(System.in);
    while (true) {
      tollPlaza.tollOperations();
      if (sc.hasNext()) {
        int optionSelected = sc.nextInt();
        tollPlaza.processOperation(optionSelected, sc);
      }
    }
  }
}